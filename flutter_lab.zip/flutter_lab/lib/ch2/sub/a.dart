int a = 10;
void aFun() {}