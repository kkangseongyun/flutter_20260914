import 'package:flutter/material.dart';

class MyInfoScreen extends StatefulWidget {
  @override
  State<MyInfoScreen> createState() => _MyInfoScreenState();
}

class _MyInfoScreenState extends State<MyInfoScreen> {
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('내 정보'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 30),
              // 원형 프로필 이미지
              Card(
                elevation: 0,
                shape: CircleBorder(),
                clipBehavior: Clip.antiAlias,
                child: Container(
                  width: 150,
                  height: 150,
                  child: Image.asset(_userImage, fit: BoxFit.cover),
                ),
              ),
              SizedBox(height: 24),
              // Gallery 버튼
              ElevatedButton(
                onPressed: (){},
                child: Text('Gallery App'),
              ),
              SizedBox(height: 24),
              // Camera 버튼
              ElevatedButton(onPressed: (){}, child: Text('Camera App')),
              SizedBox(height: 30),

		
            ],
          ),
        ),
      ),
    );
  }
}
