import 'package:sqflite/sqflite.dart';


class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  static Database? _database;

  factory DatabaseHelper() {
    return _instance;
  }

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    return await openDatabase(
          );
  }

  Future<int> insertMyInfo(Map<String, dynamic> data) async {
    final db = await database;
    await db.delete('TB_MYINFO');
    return await db.insert('TB_MYINFO', data);
  }

  Future<List<Map<String, dynamic>>> getMyInfo() async {
    final db = await database;
    return await db.query('TB_MYINFO');
  }
}